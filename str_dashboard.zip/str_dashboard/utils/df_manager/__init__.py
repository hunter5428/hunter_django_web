# str_dashboard/utils/df_manager/__init__.py
"""
DataFrame 관리 유틸리티 패키지
"""

from .dataframe_manager import DataFrameManager

__all__ = ['DataFrameManager']